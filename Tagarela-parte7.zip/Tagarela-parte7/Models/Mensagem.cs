using System;

namespace Tagarela.Models
{
    public class Mensagem
    {
        public int Id { get; set; }
        public string Conteudo { get; set; }

        public DateTime CriadoEm { get; set; } = DateTime.Now;

        public User Autor { get; set; }

        public long Curtidas { get; set; }

        public Mensagem Retagarelada { get; set; }
    }
}
